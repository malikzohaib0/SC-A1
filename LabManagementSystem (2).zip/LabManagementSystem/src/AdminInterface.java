import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AdminInterface extends JFrame {
    public AdminInterface() {
        setTitle("Admin Dashboard");
        setSize(1200, 800);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main panel with gradient background
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                Color color1 = new Color(20, 30, 48);
                Color color2 = new Color(36, 59, 85);
                GradientPaint gp = new GradientPaint(0, 0, color1, getWidth(), getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        // Header panel
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JLabel titleLabel = new JLabel("Admin Dashboard");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);

        JButton logoutButton = new JButton("Logout");
        styleButton(logoutButton);
        logoutButton.addActionListener(e -> {
            new LoginScreen();
            dispose();
        });

        headerPanel.add(titleLabel, BorderLayout.WEST);
        headerPanel.add(logoutButton, BorderLayout.EAST);

        // Button panel
        JPanel buttonPanel = new JPanel(new GridLayout(5, 1, 10, 10));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        String[] buttonNames = {
                "User Management",
                "Labs/Computers Management",
                "Specifications Management",
                "HW/SW Requests",
                "Complaints Management"
        };

        for (String name : buttonNames) {
            JButton button = new JButton(name);
            styleMenuButton(button);
            buttonPanel.add(button);
        }

        // Add action listeners to buttons
        ((JButton) buttonPanel.getComponent(0)).addActionListener(e -> new UserLoginManager());
        ((JButton) buttonPanel.getComponent(1)).addActionListener(e -> new LabComManager());
        ((JButton) buttonPanel.getComponent(2)).addActionListener(e -> new SpecsManager());
        ((JButton) buttonPanel.getComponent(3)).addActionListener(e -> new RequestManager());
        ((JButton) buttonPanel.getComponent(4)).addActionListener(e -> new ComplaintsManager());

        // Add components to main panel
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(buttonPanel, BorderLayout.CENTER);

        add(mainPanel);
        setVisible(true);
    }

    private void styleButton(JButton button) {
        button.setBackground(new Color(33, 147, 176));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
    }

    private void styleMenuButton(JButton button) {
        button.setBackground(new Color(44, 62, 80));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("Segoe UI", Font.BOLD, 18));
        button.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(52, 73, 94));
            }

            public void mouseExited(MouseEvent e) {
                button.setBackground(new Color(44, 62, 80));
            }
        });
    }

    // Inner classes for each management module
    class UserLoginManager extends JFrame {
        private List<String[]> users = new ArrayList<>();
        private JTable userTable;
        private JTextField emailField, passwordField, roleField;
        private DefaultTableModel tableModel;

        public UserLoginManager() {
            setTitle("User Management");
            setSize(800, 600);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            loadUsers();

            JPanel mainPanel = new JPanel(new BorderLayout());
            mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

            // Table
            String[] columns = { "Email", "Password", "Role" };
            tableModel = new DefaultTableModel(users.toArray(new Object[0][]), columns);
            userTable = new JTable(tableModel);
            JScrollPane scrollPane = new JScrollPane(userTable);

            // Add selection listener
            userTable.getSelectionModel().addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = userTable.getSelectedRow();
                    if (selectedRow >= 0) {
                        emailField.setText(users.get(selectedRow)[0]);
                        passwordField.setText(users.get(selectedRow)[1]);
                        roleField.setText(users.get(selectedRow)[2]);
                    }
                }
            });

            // Form panel
            JPanel formPanel = new JPanel(new GridLayout(3, 2, 5, 5));
            emailField = new JTextField();
            passwordField = new JPasswordField();
            roleField = new JTextField();

            formPanel.add(new JLabel("Email:"));
            formPanel.add(emailField);
            formPanel.add(new JLabel("Password:"));
            formPanel.add(passwordField);
            formPanel.add(new JLabel("Role (admin/user):"));
            formPanel.add(roleField);

            // Button panel
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            JButton addButton = new JButton("Add User");
            JButton updateButton = new JButton("Update User");
            JButton deleteButton = new JButton("Delete User");

            addButton.addActionListener(e -> addUser());
            updateButton.addActionListener(e -> updateUser());
            deleteButton.addActionListener(e -> deleteUser());

            buttonPanel.add(addButton);
            buttonPanel.add(updateButton);
            buttonPanel.add(deleteButton);

            mainPanel.add(scrollPane, BorderLayout.CENTER);
            mainPanel.add(formPanel, BorderLayout.NORTH);
            mainPanel.add(buttonPanel, BorderLayout.SOUTH);

            add(mainPanel);
            setVisible(true);
        }

        private void loadUsers() {
            users.clear();
            try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length == 3) {
                        // Fix role display (convert true/false to admin/user)
                        String role = parts[2].equals("true") ? "admin" : "user";
                        users.add(new String[] { parts[0], parts[1], role });
                    }
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error loading users", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        private void saveUsers() {
            try (PrintWriter writer = new PrintWriter(new FileWriter("users.txt"))) {
                for (String[] user : users) {
                    // Convert role back to true/false format for storage
                    String roleValue = user[2].equalsIgnoreCase("admin") ? "true" : "false";
                    writer.println(user[0] + "," + user[1] + "," + roleValue);
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error saving users", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        private void addUser() {
            String email = emailField.getText().trim();
            String password = passwordField.getText().trim();
            String role = roleField.getText().trim().toLowerCase();

            if (email.isEmpty() || password.isEmpty() || (!role.equals("admin") && !role.equals("user"))) {
                JOptionPane.showMessageDialog(this, "Please fill all fields correctly", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Check if user already exists
            for (String[] user : users) {
                if (user[0].equalsIgnoreCase(email)) {
                    JOptionPane.showMessageDialog(this, "User with this email already exists", "Error",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

            users.add(new String[] { email, password, role });
            saveUsers();
            tableModel.addRow(new Object[] { email, password, role });
            clearFields();
        }

        private void updateUser() {
            int selectedRow = userTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select a user to update", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            String email = emailField.getText().trim();
            String password = passwordField.getText().trim();
            String role = roleField.getText().trim().toLowerCase();

            if (email.isEmpty() || password.isEmpty() || (!role.equals("admin") && !role.equals("user"))) {
                JOptionPane.showMessageDialog(this, "Please fill all fields correctly", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Check if email is being changed to an existing one
            if (!users.get(selectedRow)[0].equalsIgnoreCase(email)) {
                for (String[] user : users) {
                    if (user[0].equalsIgnoreCase(email)) {
                        JOptionPane.showMessageDialog(this, "User with this email already exists", "Error",
                                JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
            }

            users.set(selectedRow, new String[] { email, password, role });
            saveUsers();
            tableModel.setValueAt(email, selectedRow, 0);
            tableModel.setValueAt(password, selectedRow, 1);
            tableModel.setValueAt(role, selectedRow, 2);
            clearFields();
        }

        private void deleteUser() {
            int selectedRow = userTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select a user to delete", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            users.remove(selectedRow);
            saveUsers();
            tableModel.removeRow(selectedRow);
            clearFields();
        }

        private void clearFields() {
            emailField.setText("");
            passwordField.setText("");
            roleField.setText("");
        }
    }

    class LabComManager extends JFrame {
        private List<String[]> labs = new ArrayList<>();
        private List<String[]> computers = new ArrayList<>();
        private JTable labTable, computerTable;
        private JTextField labNameField, labDeptField, labCapacityField, labLocationField;
        private JTextField compIdField, compLabField, compOSField, compRAMField, compCPUField, compDateField;
    
        public LabComManager() {
            setTitle("Lab & Computer Management");
            setSize(1200, 800);
            setLocationRelativeTo(null);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
            loadLabs();
            loadComputers();
    
            JTabbedPane tabbedPane = new JTabbedPane();
    
            // Lab Management Tab
            JPanel labPanel = new JPanel(new BorderLayout());
            labPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    
            // Lab Table
            String[] labColumns = { "Lab Name", "Department", "Capacity", "Location" };
            DefaultTableModel labTableModel = new DefaultTableModel(labColumns, 0);
            labTable = new JTable(labTableModel);
            refreshLabTable();
            
            // Add mouse listener for lab table
            labTable.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    int selectedRow = labTable.getSelectedRow();
                    if (selectedRow >= 0) {
                        labNameField.setText(labTable.getValueAt(selectedRow, 0).toString());
                        labDeptField.setText(labTable.getValueAt(selectedRow, 1).toString());
                        labCapacityField.setText(labTable.getValueAt(selectedRow, 2).toString());
                        labLocationField.setText(labTable.getValueAt(selectedRow, 3).toString());
                    }
                }
            });
            
            JScrollPane labScrollPane = new JScrollPane(labTable);
    
            // Lab Form
            JPanel labFormPanel = new JPanel(new GridLayout(4, 2, 5, 5));
            labNameField = new JTextField();
            labDeptField = new JTextField();
            labCapacityField = new JTextField();
            labLocationField = new JTextField();
    
            labFormPanel.add(new JLabel("Lab Name:"));
            labFormPanel.add(labNameField);
            labFormPanel.add(new JLabel("Department:"));
            labFormPanel.add(labDeptField);
            labFormPanel.add(new JLabel("Capacity:"));
            labFormPanel.add(labCapacityField);
            labFormPanel.add(new JLabel("Location:"));
            labFormPanel.add(labLocationField);
    
            // Lab Buttons
            JPanel labButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            JButton addLabButton = new JButton("Add Lab");
            JButton updateLabButton = new JButton("Update Lab");
            JButton deleteLabButton = new JButton("Delete Lab");
            JButton clearLabButton = new JButton("Clear");
    
            addLabButton.addActionListener(e -> addLab());
            updateLabButton.addActionListener(e -> updateLab());
            deleteLabButton.addActionListener(e -> deleteLab());
            clearLabButton.addActionListener(e -> clearLabFields());
    
            labButtonPanel.add(addLabButton);
            labButtonPanel.add(updateLabButton);
            labButtonPanel.add(deleteLabButton);
            labButtonPanel.add(clearLabButton);
    
            labPanel.add(labFormPanel, BorderLayout.NORTH);
            labPanel.add(labScrollPane, BorderLayout.CENTER);
            labPanel.add(labButtonPanel, BorderLayout.SOUTH);
    
            // Computer Management Tab
            JPanel computerPanel = new JPanel(new BorderLayout());
            computerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    
            // Computer Table
            String[] compColumns = { "Computer ID", "Lab", "OS", "RAM", "CPU", "Install Date" };
            DefaultTableModel compTableModel = new DefaultTableModel(compColumns, 0);
            computerTable = new JTable(compTableModel);
            refreshComputerTable();
            
            // Add mouse listener for computer table
            computerTable.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    int selectedRow = computerTable.getSelectedRow();
                    if (selectedRow >= 0) {
                        compIdField.setText(computerTable.getValueAt(selectedRow, 0).toString());
                        compLabField.setText(computerTable.getValueAt(selectedRow, 1).toString());
                        compOSField.setText(computerTable.getValueAt(selectedRow, 2).toString());
                        compRAMField.setText(computerTable.getValueAt(selectedRow, 3).toString());
                        compCPUField.setText(computerTable.getValueAt(selectedRow, 4).toString());
                        compDateField.setText(computerTable.getValueAt(selectedRow, 5).toString());
                    }
                }
            });
            
            JScrollPane compScrollPane = new JScrollPane(computerTable);
    
            // Computer Form
            JPanel compFormPanel = new JPanel(new GridLayout(6, 2, 5, 5));
            compIdField = new JTextField();
            compLabField = new JTextField();
            compOSField = new JTextField();
            compRAMField = new JTextField();
            compCPUField = new JTextField();
            compDateField = new JTextField();
    
            compFormPanel.add(new JLabel("Computer ID:"));
            compFormPanel.add(compIdField);
            compFormPanel.add(new JLabel("Lab:"));
            compFormPanel.add(compLabField);
            compFormPanel.add(new JLabel("Operating System:"));
            compFormPanel.add(compOSField);
            compFormPanel.add(new JLabel("RAM:"));
            compFormPanel.add(compRAMField);
            compFormPanel.add(new JLabel("CPU:"));
            compFormPanel.add(compCPUField);
            compFormPanel.add(new JLabel("Install Date (YYYY-MM-DD):"));
            compFormPanel.add(compDateField);
    
            // Computer Buttons
            JPanel compButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            JButton addCompButton = new JButton("Add Computer");
            JButton updateCompButton = new JButton("Update Computer");
            JButton deleteCompButton = new JButton("Delete Computer");
            JButton clearCompButton = new JButton("Clear");
    
            addCompButton.addActionListener(e -> addComputer());
            updateCompButton.addActionListener(e -> updateComputer());
            deleteCompButton.addActionListener(e -> deleteComputer());
            clearCompButton.addActionListener(e -> clearComputerFields());
    
            compButtonPanel.add(addCompButton);
            compButtonPanel.add(updateCompButton);
            compButtonPanel.add(deleteCompButton);
            compButtonPanel.add(clearCompButton);
    
            computerPanel.add(compFormPanel, BorderLayout.NORTH);
            computerPanel.add(compScrollPane, BorderLayout.CENTER);
            computerPanel.add(compButtonPanel, BorderLayout.SOUTH);
    
            // Add tabs
            tabbedPane.addTab("Lab Management", labPanel);
            tabbedPane.addTab("Computer Management", computerPanel);
    
            add(tabbedPane);
            setVisible(true);
        }
    
        private void loadLabs() {
            labs.clear();
            try (BufferedReader reader = new BufferedReader(new FileReader("labs.txt"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length == 4) {
                        labs.add(new String[] { parts[0], parts[1], parts[2], parts[3] });
                    }
                }
            } catch (IOException e) {
                // File doesn't exist yet, that's okay
            }
        }
    
        private void saveLabs() {
            try (PrintWriter writer = new PrintWriter(new FileWriter("labs.txt"))) {
                for (String[] lab : labs) {
                    writer.println(String.join(",", lab));
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error saving labs", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    
        private void loadComputers() {
            computers.clear();
            try (BufferedReader reader = new BufferedReader(new FileReader("computers.txt"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length == 6) {
                        computers.add(new String[] { parts[0], parts[1], parts[2], parts[3], parts[4], parts[5] });
                    }
                }
            } catch (IOException e) {
                // File doesn't exist yet, that's okay
            }
        }
    
        private void saveComputers() {
            try (PrintWriter writer = new PrintWriter(new FileWriter("computers.txt"))) {
                for (String[] computer : computers) {
                    writer.println(String.join(",", computer));
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error saving computers", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    
        private void addLab() {
            String name = labNameField.getText().trim();
            String dept = labDeptField.getText().trim();
            String capacity = labCapacityField.getText().trim();
            String location = labLocationField.getText().trim();
    
            if (name.isEmpty() || dept.isEmpty() || capacity.isEmpty() || location.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
    
            labs.add(new String[] { name, dept, capacity, location });
            saveLabs();
            refreshLabTable();
            clearLabFields();
        }
    
        private void updateLab() {
            int selectedRow = labTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select a lab to update", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }
    
            String name = labNameField.getText().trim();
            String dept = labDeptField.getText().trim();
            String capacity = labCapacityField.getText().trim();
            String location = labLocationField.getText().trim();
    
            if (name.isEmpty() || dept.isEmpty() || capacity.isEmpty() || location.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
    
            labs.set(selectedRow, new String[] { name, dept, capacity, location });
            saveLabs();
            refreshLabTable();
            clearLabFields();
        }
    
        private void deleteLab() {
            int selectedRow = labTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select a lab to delete", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }
    
            // First remove all computers in this lab
            String labName = labs.get(selectedRow)[0];
            computers.removeIf(computer -> computer[1].equals(labName));
            saveComputers();
    
            // Then remove the lab
            labs.remove(selectedRow);
            saveLabs();
            refreshLabTable();
            refreshComputerTable();
            clearLabFields();
        }
    
        private void addComputer() {
            String id = compIdField.getText().trim();
            String lab = compLabField.getText().trim();
            String os = compOSField.getText().trim();
            String ram = compRAMField.getText().trim();
            String cpu = compCPUField.getText().trim();
            String date = compDateField.getText().trim();
    
            if (id.isEmpty() || lab.isEmpty() || os.isEmpty() || ram.isEmpty() || cpu.isEmpty() || date.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
    
            // Check if lab exists
            boolean labExists = labs.stream().anyMatch(l -> l[0].equals(lab));
            if (!labExists) {
                JOptionPane.showMessageDialog(this, "Lab does not exist", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
    
            computers.add(new String[] { id, lab, os, ram, cpu, date });
            saveComputers();
            refreshComputerTable();
            clearComputerFields();
        }
    
        private void updateComputer() {
            int selectedRow = computerTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select a computer to update", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }
    
            String id = compIdField.getText().trim();
            String lab = compLabField.getText().trim();
            String os = compOSField.getText().trim();
            String ram = compRAMField.getText().trim();
            String cpu = compCPUField.getText().trim();
            String date = compDateField.getText().trim();
    
            if (id.isEmpty() || lab.isEmpty() || os.isEmpty() || ram.isEmpty() || cpu.isEmpty() || date.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
    
            // Check if lab exists
            boolean labExists = labs.stream().anyMatch(l -> l[0].equals(lab));
            if (!labExists) {
                JOptionPane.showMessageDialog(this, "Lab does not exist", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
    
            computers.set(selectedRow, new String[] { id, lab, os, ram, cpu, date });
            saveComputers();
            refreshComputerTable();
            clearComputerFields();
        }
    
        private void deleteComputer() {
            int selectedRow = computerTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select a computer to delete", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }
    
            computers.remove(selectedRow);
            saveComputers();
            refreshComputerTable();
            clearComputerFields();
        }
    
        private void refreshLabTable() {
            DefaultTableModel model = (DefaultTableModel) labTable.getModel();
            model.setRowCount(0); // Clear existing data
            
            for (String[] lab : labs) {
                model.addRow(lab);
            }
        }
    
        private void refreshComputerTable() {
            DefaultTableModel model = (DefaultTableModel) computerTable.getModel();
            model.setRowCount(0); // Clear existing data
            
            for (String[] computer : computers) {
                model.addRow(computer);
            }
        }
    
        private void clearLabFields() {
            labNameField.setText("");
            labDeptField.setText("");
            labCapacityField.setText("");
            labLocationField.setText("");
        }
    
        private void clearComputerFields() {
            compIdField.setText("");
            compLabField.setText("");
            compOSField.setText("");
            compRAMField.setText("");
            compCPUField.setText("");
            compDateField.setText("");
        }
    
    }

    class SpecsManager extends JFrame {
        private List<String[]> specs = new ArrayList<>();
        private JTable specsTable;
        private JTextField computerIdField, osField, ramField, storageField, gpuField;

        public SpecsManager() {
            setTitle("Computer Specifications Management");
            setSize(900, 600);
            setLocationRelativeTo(null);

            loadSpecs();

            JPanel mainPanel = new JPanel(new BorderLayout());
            mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

            // Table
            String[] columns = { "Computer ID", "Operating System", "RAM", "Storage", "GPU" };
            Object[][] data = specs.stream().toArray(Object[][]::new);
            specsTable = new JTable(data, columns);
            specsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            JScrollPane scrollPane = new JScrollPane(specsTable);

            // Add selection listener to populate fields when row is selected
            specsTable.getSelectionModel().addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting() && specsTable.getSelectedRow() != -1) {
                    int selectedRow = specsTable.getSelectedRow();
                    computerIdField.setText((String) specsTable.getValueAt(selectedRow, 0));
                    osField.setText((String) specsTable.getValueAt(selectedRow, 1));
                    ramField.setText((String) specsTable.getValueAt(selectedRow, 2));
                    storageField.setText((String) specsTable.getValueAt(selectedRow, 3));
                    gpuField.setText((String) specsTable.getValueAt(selectedRow, 4));
                }
            });

            // Form panel
            JPanel formPanel = new JPanel(new GridLayout(5, 2, 5, 5));
            computerIdField = new JTextField();
            osField = new JTextField();
            ramField = new JTextField();
            storageField = new JTextField();
            gpuField = new JTextField();

            formPanel.add(new JLabel("Computer ID:"));
            formPanel.add(computerIdField);
            formPanel.add(new JLabel("Operating System:"));
            formPanel.add(osField);
            formPanel.add(new JLabel("RAM:"));
            formPanel.add(ramField);
            formPanel.add(new JLabel("Storage:"));
            formPanel.add(storageField);
            formPanel.add(new JLabel("GPU:"));
            formPanel.add(gpuField);

            // Button panel
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
            JButton addButton = new JButton("Add Specs");
            JButton updateButton = new JButton("Update Specs");
            JButton deleteButton = new JButton("Delete Specs");
            JButton refreshButton = new JButton("Refresh");

            styleSpecsButton(addButton);
            styleSpecsButton(updateButton);
            styleSpecsButton(deleteButton);
            styleSpecsButton(refreshButton);

            addButton.addActionListener(e -> addSpecs());
            updateButton.addActionListener(e -> updateSpecs());
            deleteButton.addActionListener(e -> deleteSpecs());
            refreshButton.addActionListener(e -> refreshSpecs());

            buttonPanel.add(addButton);
            buttonPanel.add(updateButton);
            buttonPanel.add(deleteButton);
            buttonPanel.add(refreshButton);

            mainPanel.add(scrollPane, BorderLayout.CENTER);
            mainPanel.add(formPanel, BorderLayout.NORTH);
            mainPanel.add(buttonPanel, BorderLayout.SOUTH);

            add(mainPanel);
            setVisible(true);
        }

        private void styleSpecsButton(JButton button) {
            button.setBackground(new Color(52, 152, 219));
            button.setForeground(Color.WHITE);
            button.setFocusPainted(false);
            button.setFont(new Font("Segoe UI", Font.BOLD, 12));
            button.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        }

        private void loadSpecs() {
            specs.clear();
            try (BufferedReader reader = new BufferedReader(new FileReader("specs.txt"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length == 5) {
                        specs.add(new String[] {
                                parts[0].trim(),
                                parts[1].trim(),
                                parts[2].trim(),
                                parts[3].trim(),
                                parts[4].trim()
                        });
                    }
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this,
                        "Error loading specifications: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }

        private void saveSpecs() {
            try (PrintWriter writer = new PrintWriter(new FileWriter("specs.txt"))) {
                for (String[] spec : specs) {
                    writer.println(String.join(",", spec));
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this,
                        "Error saving specifications: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }

        private void addSpecs() {
            String computerId = computerIdField.getText().trim();
            String os = osField.getText().trim();
            String ram = ramField.getText().trim();
            String storage = storageField.getText().trim();
            String gpu = gpuField.getText().trim();

            if (computerId.isEmpty() || os.isEmpty() || ram.isEmpty() || storage.isEmpty() || gpu.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Please fill all fields",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            specs.add(new String[] { computerId, os, ram, storage, gpu });
            saveSpecs();
            refreshSpecs();
            clearFields();
        }

        private void updateSpecs() {
            int selectedRow = specsTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this,
                        "Please select a specification to update",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            String computerId = computerIdField.getText().trim();
            String os = osField.getText().trim();
            String ram = ramField.getText().trim();
            String storage = storageField.getText().trim();
            String gpu = gpuField.getText().trim();

            if (computerId.isEmpty() || os.isEmpty() || ram.isEmpty() || storage.isEmpty() || gpu.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Please fill all fields",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            specs.set(selectedRow, new String[] { computerId, os, ram, storage, gpu });
            saveSpecs();
            refreshSpecs();
            clearFields();
        }

        private void deleteSpecs() {
            int selectedRow = specsTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this,
                        "Please select a specification to delete",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete these specifications?",
                    "Confirm Delete",
                    JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                specs.remove(selectedRow);
                saveSpecs();
                refreshSpecs();
                clearFields();
            }
        }

        private void refreshSpecs() {
            loadSpecs();
            specsTable.setModel(new javax.swing.table.DefaultTableModel(
                    specs.stream().toArray(Object[][]::new),
                    new String[] { "Computer ID", "Operating System", "RAM", "Storage", "GPU" }));
        }

        private void clearFields() {
            computerIdField.setText("");
            osField.setText("");
            ramField.setText("");
            storageField.setText("");
            gpuField.setText("");
        }
    }

 class RequestManager extends JFrame {
    private List<String[]> requests = new ArrayList<>();
    private JTable requestTable;
    private JTextField userField, dateField, typeField, pcField, nameField, descriptionField, commentField;
    private JComboBox<String> statusComboBox;

    public RequestManager() {
        setTitle("HW/SW Request Management");
        setSize(1300, 600);  // Increased width to accommodate extra column
        setLocationRelativeTo(null);

        loadRequests();

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Table
        String[] columns = { "User Email", "Date", "Type", "PC", "Name", "Description", "Status", "Comment" };
        Object[][] data = requests.stream().map(req -> {
            // Ensure we always have 8 columns (comment might be missing)
            String[] row = new String[8];
            System.arraycopy(req, 0, row, 0, Math.min(req.length, 7));
            if (req.length > 7) row[7] = req[7];  // Copy comment if exists
            return row;
        }).toArray(Object[][]::new);
        requestTable = new JTable(data, columns);
        JScrollPane scrollPane = new JScrollPane(requestTable);

        // Form panel
        JPanel formPanel = new JPanel(new GridLayout(8, 2, 5, 5));  // Changed to 8 rows
        userField = new JTextField();
        dateField = new JTextField();
        typeField = new JTextField();
        pcField = new JTextField();  // New field for PC
        nameField = new JTextField();
        descriptionField = new JTextField();
        commentField = new JTextField();

        String[] statusOptions = { "Pending", "Approved", "Denied", "Completed" };
        statusComboBox = new JComboBox<>(statusOptions);

        formPanel.add(new JLabel("User Email:"));
        formPanel.add(userField);
        formPanel.add(new JLabel("Date (YYYY-MM-DD):"));
        formPanel.add(dateField);
        formPanel.add(new JLabel("Type (HW/SW):"));
        formPanel.add(typeField);
        formPanel.add(new JLabel("PC:"));
        formPanel.add(pcField);
        formPanel.add(new JLabel("Name:"));
        formPanel.add(nameField);
        formPanel.add(new JLabel("Description:"));
        formPanel.add(descriptionField);
        formPanel.add(new JLabel("Status:"));
        formPanel.add(statusComboBox);
        formPanel.add(new JLabel("Comment:"));
        formPanel.add(commentField);

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        JButton updateButton = new JButton("Update Status");
        JButton addCommentButton = new JButton("Add Comment");
        JButton refreshButton = new JButton("Refresh");

        updateButton.addActionListener(e -> updateRequest());
        addCommentButton.addActionListener(e -> addComment());
        refreshButton.addActionListener(e -> refreshRequests());

        buttonPanel.add(updateButton);
        buttonPanel.add(addCommentButton);
        buttonPanel.add(refreshButton);

        // Add table selection listener
        requestTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = requestTable.getSelectedRow();
                if (selectedRow >= 0) {
                    userField.setText((String) requestTable.getValueAt(selectedRow, 0));
                    dateField.setText((String) requestTable.getValueAt(selectedRow, 1));
                    typeField.setText((String) requestTable.getValueAt(selectedRow, 2));
                    pcField.setText((String) requestTable.getValueAt(selectedRow, 3));
                    nameField.setText((String) requestTable.getValueAt(selectedRow, 4));
                    descriptionField.setText((String) requestTable.getValueAt(selectedRow, 5));
                    statusComboBox.setSelectedItem(requestTable.getValueAt(selectedRow, 6));
                    commentField.setText(requestTable.getValueAt(selectedRow, 7) != null ? 
                                       (String) requestTable.getValueAt(selectedRow, 7) : "");
                }
            }
        });

        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(formPanel, BorderLayout.NORTH);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);
        setVisible(true);
    }

    private void loadRequests() {
        requests.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader("requests.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Split into maximum 8 parts (comment may contain commas)
                String[] parts = line.split(",", 8);
                if (parts.length >= 7) {
                    // Ensure we always have 8 elements (comment might be missing)
                    String[] request = new String[8];
                    System.arraycopy(parts, 0, request, 0, Math.min(parts.length, 8));
                    requests.add(request);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading requests", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveRequests() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("requests.txt"))) {
            for (String[] request : requests) {
                // Only write fields up to the last non-empty one
                int lastNonEmpty = request.length - 1;
                while (lastNonEmpty >= 0 && (request[lastNonEmpty] == null || request[lastNonEmpty].isEmpty())) {
                    lastNonEmpty--;
                }
                String[] toWrite = Arrays.copyOfRange(request, 0, lastNonEmpty + 1);
                writer.println(String.join(",", toWrite));
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving requests", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateRequest() {
        int selectedRow = requestTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a request to update", "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        String newStatus = (String) statusComboBox.getSelectedItem();
        requests.get(selectedRow)[6] = newStatus;  // Status is now at index 6

        saveRequests();
        refreshRequests();
        JOptionPane.showMessageDialog(this, "Request status updated successfully", "Success",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private void addComment() {
        int selectedRow = requestTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a request to comment on", "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        String comment = JOptionPane.showInputDialog(this, "Enter your comment:");
        if (comment != null && !comment.trim().isEmpty()) {
            String[] request = requests.get(selectedRow);
            if (request.length < 8 || request[7] == null || request[7].isEmpty()) {
                // If no comment exists yet
                String[] newRequest = new String[8];
                System.arraycopy(request, 0, newRequest, 0, 7);
                newRequest[7] = comment;
                requests.set(selectedRow, newRequest);
            } else {
                // Append to existing comment
                request[7] = request[7] + "; " + comment;
            }

            saveRequests();
            refreshRequests();
            JOptionPane.showMessageDialog(this, "Comment added successfully", "Success",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void refreshRequests() {
        loadRequests();
        requestTable.setModel(new javax.swing.table.DefaultTableModel(
                requests.stream().map(req -> {
                    String[] row = new String[8];
                    System.arraycopy(req, 0, row, 0, Math.min(req.length, 8));
                    return row;
                }).toArray(Object[][]::new),
                new String[] { "User Email", "Date", "Type", "PC", "Name", "Description", "Status", "Comment" }));

        // Clear fields
        userField.setText("");
        dateField.setText("");
        typeField.setText("");
        pcField.setText("");
        nameField.setText("");
        descriptionField.setText("");
        commentField.setText("");
        statusComboBox.setSelectedIndex(0);
    }
}
class ComplaintsManager extends JFrame {
    private List<String[]> complaints = new ArrayList<>();
    private JTable complaintsTable;
    private JTextArea complaintArea;
    private JTextArea replyArea;
    private JComboBox<String> statusCombo;

    public ComplaintsManager() {
        setTitle("Complaints Management");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        loadComplaints();

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Table
        String[] columns = {"User Email", "Date", "Type", "Complaint", "Status", "Reply"};
        complaintsTable = new JTable(new ComplaintTableModel(complaints, columns));
        complaintsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        complaintsTable.getSelectionModel().addListSelectionListener(e -> showComplaintDetails());

        JScrollPane tableScroll = new JScrollPane(complaintsTable);
        tableScroll.setPreferredSize(new Dimension(600, 400));

        // Details panel
        JPanel detailsPanel = new JPanel(new BorderLayout(5, 5));
        detailsPanel.setBorder(BorderFactory.createTitledBorder("Complaint Details"));

        // Complaint display area
        complaintArea = new JTextArea();
        complaintArea.setEditable(false);
        complaintArea.setLineWrap(true);
        complaintArea.setWrapStyleWord(true);
        complaintArea.setBorder(BorderFactory.createTitledBorder("Complaint Text"));

        // Reply area
        replyArea = new JTextArea();
        replyArea.setLineWrap(true);
        replyArea.setWrapStyleWord(true);
        replyArea.setBorder(BorderFactory.createTitledBorder("Admin Reply"));

        // Status panel
        statusCombo = new JComboBox<>(new String[]{"Pending", "In Progress", "Resolved", "Rejected"});
        statusCombo.setBorder(BorderFactory.createTitledBorder("Status"));

        JButton updateButton = new JButton("Update Complaint");
        updateButton.addActionListener(e -> updateComplaint());
        styleButton(updateButton);

        JPanel statusPanel = new JPanel(new BorderLayout(5, 5));
        statusPanel.add(statusCombo, BorderLayout.CENTER);
        statusPanel.add(updateButton, BorderLayout.SOUTH);

        // Combine components
        JPanel textPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        textPanel.add(new JScrollPane(complaintArea));
        textPanel.add(new JScrollPane(replyArea));

        detailsPanel.add(textPanel, BorderLayout.CENTER);
        detailsPanel.add(statusPanel, BorderLayout.NORTH);

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> refreshComplaints());
        styleButton(refreshButton);

        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dispose());
        styleButton(closeButton);

        buttonPanel.add(refreshButton);
        buttonPanel.add(closeButton);

        // Add components
        mainPanel.add(tableScroll, BorderLayout.CENTER);
        mainPanel.add(detailsPanel, BorderLayout.EAST);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);
        setVisible(true);
    }

    private void styleButton(JButton button) {
        button.setBackground(new Color(33, 147, 176));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
    }

    private void loadComplaints() {
        complaints.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader("complaints.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Format: email,date,type,complaint,status,reply
                String[] parts = line.split(",", 6);
                if (parts.length >= 5) {
                    String status = parts[4];
                    String reply = parts.length == 6 ? parts[5] : "";
                    complaints.add(new String[]{parts[0], parts[1], parts[2], parts[3], status, reply});
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this,
                    "Error loading complaints: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveComplaints() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("complaints.txt"))) {
            for (String[] complaint : complaints) {
                writer.println(String.join(",",
                        complaint[0], // email
                        complaint[1], // date
                        complaint[2], // type
                        complaint[3], // complaint text
                        complaint[4], // status
                        complaint.length > 5 ? complaint[5] : "" // reply
                ));
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this,
                    "Error saving complaints: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showComplaintDetails() {
        int selectedRow = complaintsTable.getSelectedRow();
        if (selectedRow >= 0 && selectedRow < complaints.size()) {
            String[] complaint = complaints.get(selectedRow);
            complaintArea.setText(complaint[3]); // Complaint text
            statusCombo.setSelectedItem(complaint[4]); // Status
            replyArea.setText(complaint.length > 5 ? complaint[5] : ""); // Reply
        }
    }

    private void updateComplaint() {
        int selectedRow = complaintsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a complaint", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String status = (String) statusCombo.getSelectedItem();
        String reply = replyArea.getText().trim();

        // Update the complaint data
        String[] complaint = complaints.get(selectedRow);
        complaint[4] = status; // Update status
        if (complaint.length > 5) {
            complaint[5] = reply; // Update reply
        } else {
            // If the array isn't big enough, create a new one with reply
            complaints.set(selectedRow, new String[]{
                    complaint[0], complaint[1], complaint[2], complaint[3], status, reply
            });
        }

        saveComplaints();
        refreshComplaints();
        JOptionPane.showMessageDialog(this, "Complaint updated successfully", "Success",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private void refreshComplaints() {
        loadComplaints();
        ((ComplaintTableModel) complaintsTable.getModel()).fireTableDataChanged();
    }

    private class ComplaintTableModel extends AbstractTableModel {
        private final List<String[]> data;
        private final String[] columns;

        public ComplaintTableModel(List<String[]> data, String[] columns) {
            this.data = data;
            this.columns = columns;
        }

        @Override
        public int getRowCount() {
            return data.size();
        }

        @Override
        public int getColumnCount() {
            return columns.length;
        }

        @Override
        public String getColumnName(int column) {
            return columns[column];
        }

        @Override
        public Object getValueAt(int rowIndex, int columnIndex) {
            String[] row = data.get(rowIndex);
            switch (columnIndex) {
                case 0: return row[0]; // Email
                case 1: return row[1]; // Date
                case 2: return row[2]; // Type
                case 3: // Complaint (abbreviated)
                    String complaint = row[3];
                    return complaint.length() > 50 ? complaint.substring(0, 47) + "..." : complaint;
                case 4: return row[4]; // Status
                case 5: // Reply (abbreviated)
                    String reply = row.length > 5 ? row[5] : "";
                    return reply.length() > 30 ? reply.substring(0, 27) + "..." : reply;
                default: return null;
            }
        }
    }
}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AdminInterface());
    }
}